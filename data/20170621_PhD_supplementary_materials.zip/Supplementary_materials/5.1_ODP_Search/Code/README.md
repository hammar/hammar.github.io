# Introduction

This document summarises the results of the AMI1 experiments
performed in February through March of 2014 by
[Karl Hammar](karl@karlhammar.com). The code is provided as-is,
with no guarantees as to functionality or safety. Run at your
own risk.

# Directory structure

The project directory is structured as follows:

* **src** - Java code of the experiments.
* **datasets** - Input datasets go here.
* **index** - Contains the Lucene index. Generated when building
  the pattern index as described below.
* **lib** - Contains libraries needed for the experiments to
run, including:
  * [JWI](http://projects.csail.mit.edu/jwi/)
  * [Apache Commons](http://commons.apache.org/)
  * [Guava](https://code.google.com/p/guava-libraries/)
  * [Lucene](http://lucene.apache.org/)
  * [OWLAPI](http://owlapi.sourceforge.net/)
  * [Semantic Vectors](https://code.google.com/p/semanticvectors/)
* **patterns** - Contains the pattern set used for the
  experiments, harvested from
[OntologyDesignPatterns.org](http://ontologydesignpatterns.org/)
* **wordnet** - Contains the WordNet installation required by
[JWI](http://projects.csail.mit.edu/jwi/) (MIT Java Wordnet Interface)
* **docvectors.bin, termvectors.bin, etc** - Semantic Vectors
  Search index files, regenerated when building the semantic
  index as described below.

# How to run

1.  Open the project in Eclipse. We do not make use of Maven
    or any such fancy dependency management stuff so it should
    just work to open up.

2.  Execute com.karlhammar.ami1.IndexFiles with the parameter
    "-docs patterns" to build a Lucene index of the patterns directory.

3.  Execute pitt.search.semanticvectors.BuildIndex with the
    parameters "-luceneindexpath index -trainingcycles 2" to
    build a Semantic Vectors index over the newly generated
    Lucene index.

4.  Execute com.karlhammar.ami1.RunAmi to run the experiment.
    Vary the dataset used (if you have several) by changing the source
    code in the second paragraph of the main() function. Vary
    the returned number of patterns by modifying the inner for
    loop that iterates over the result list, towards the end of
    the main() function.

# What works best

Having tried a multitude of different ways of matching
Ontology Design Patterns to input competency questions,
I've found that the best overall matching method consists
of combining three methods, with equal weighting:

1. **Semantic Vectors Search**

  Operates across the set of all local
  URI:s, all labels, and all comments of all OWL entities.
  In the code this is the *SemanticVectorSearch()* method,
  which requires the existence of a prebuilt SVS index
  (see *How to run*). Scores returned are between 0 and 1.

2. **CQ Edit distance**

  Implemented in *CQEditDistanceSearch()*. Compares the input
  competency question with each pattern competency question and
  calculates a relative Levenshtein edit distance between them.
  A ranking score of 0 indicates the strings have the maximum
  possible distance (i.e. each letter would need be changed to
  reach the same string) whereas a score of 1 indicates no
  distance at all (the CQ:s are identical).

3. **WordNet Synonym and Hypernym Matching**

  In this method the synonyms of terms occurring in the patterns
  are found through WordNet at index time. At runtime the terms
  in the input query are similarly extended with their WordNet
  synonyms and hypernyms (the latter since patterns are supposed
  to represent more general/abstract phenomena). The sets of
  extended terms are then compared, and those patterns with a
  large overlap are ranked higher (here the term frequency is
  also taken into account).
